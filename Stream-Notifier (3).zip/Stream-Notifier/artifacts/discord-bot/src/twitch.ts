import axios from "axios";

const CLIENT_ID = process.env.TWITCH_CLIENT_ID!;
const CLIENT_SECRET = process.env.TWITCH_CLIENT_SECRET!;

let accessToken: string | null = null;
let tokenExpiresAt = 0;

async function getAccessToken(): Promise<string> {
  if (accessToken && Date.now() < tokenExpiresAt) return accessToken;

  const res = await axios.post<{ access_token: string; expires_in: number }>(
    "https://id.twitch.tv/oauth2/token",
    null,
    {
      params: {
        client_id: CLIENT_ID,
        client_secret: CLIENT_SECRET,
        grant_type: "client_credentials",
      },
    }
  );

  accessToken = res.data.access_token;
  tokenExpiresAt = Date.now() + res.data.expires_in * 1000 - 60_000;
  return accessToken;
}

export interface StreamInfo {
  id: string;
  userId: string;
  userName: string;
  userLogin: string;
  gameName: string;
  title: string;
  viewerCount: number;
  startedAt: string;
  thumbnailUrl: string;
  profileImageUrl: string;
}

export async function getBroadcasterId(login: string): Promise<string | null> {
  const token = await getAccessToken();
  const res = await axios.get<{ data: Array<{ id: string }> }>(
    "https://api.twitch.tv/helix/users",
    {
      headers: { "Client-ID": CLIENT_ID, Authorization: `Bearer ${token}` },
      params: { login },
    }
  );
  return res.data.data[0]?.id ?? null;
}

export async function createClip(broadcasterId: string): Promise<{ id: string; editUrl: string } | null> {
  const oauthToken = process.env.TWITCH_OAUTH_TOKEN;
  if (!oauthToken) return null;

  const token = oauthToken.startsWith("oauth:") ? oauthToken.slice(6) : oauthToken;

  const res = await axios.post<{ data: Array<{ id: string; edit_url: string }> }>(
    "https://api.twitch.tv/helix/clips",
    null,
    {
      headers: { "Client-ID": CLIENT_ID, Authorization: `Bearer ${token}` },
      params: { broadcaster_id: broadcasterId },
    }
  );

  const clip = res.data.data[0];
  if (!clip) return null;
  return { id: clip.id, editUrl: clip.edit_url };
}

export async function getStreamInfo(streamerName: string): Promise<StreamInfo | null> {
  const token = await getAccessToken();

  const streamRes = await axios.get<{ data: Array<{
    id: string;
    user_id: string;
    user_name: string;
    user_login: string;
    game_name: string;
    title: string;
    viewer_count: number;
    started_at: string;
    thumbnail_url: string;
  }> }>("https://api.twitch.tv/helix/streams", {
    headers: {
      "Client-ID": CLIENT_ID,
      Authorization: `Bearer ${token}`,
    },
    params: { user_login: streamerName },
  });

  const stream = streamRes.data.data[0];
  if (!stream) return null;

  const userRes = await axios.get<{ data: Array<{ profile_image_url: string }> }>(
    "https://api.twitch.tv/helix/users",
    {
      headers: {
        "Client-ID": CLIENT_ID,
        Authorization: `Bearer ${token}`,
      },
      params: { login: streamerName },
    }
  );

  const profileImageUrl = userRes.data.data[0]?.profile_image_url ?? "";

  return {
    id: stream.id,
    userId: stream.user_id,
    userName: stream.user_name,
    userLogin: stream.user_login,
    gameName: stream.game_name,
    title: stream.title,
    viewerCount: stream.viewer_count,
    startedAt: stream.started_at,
    thumbnailUrl: stream.thumbnail_url
      .replace("{width}", "1280")
      .replace("{height}", "720"),
    profileImageUrl,
  };
}
