import tmi from "tmi.js";
import { getTwitchMessages } from "./twitch-messages.js";
import { findCommand } from "./twitch-commands.js";
import { getBroadcasterId, createClip } from "./twitch.js";

const CHANNEL = process.env.TWITCH_CHANNEL ?? "dipariss7";
const USERNAME = process.env.TWITCH_BOT_USERNAME!;
const OAUTH_TOKEN = process.env.TWITCH_OAUTH_TOKEN!;

const RECONNECT_DELAYS_MS = [5_000, 10_000, 30_000, 60_000];

let client: tmi.Client | null = null;
let intervalHandles: ReturnType<typeof setInterval>[] = [];
let reconnecting = false;
let reconnectAttempt = 0;
let streamerIsLive = false;
let clipCooldownUntil = 0;
const CLIP_COOLDOWN_MS = 30_000;

export async function startTwitchChat(): Promise<void> {
  if (!USERNAME || !OAUTH_TOKEN) {
    console.warn("⚠️ TWITCH_BOT_USERNAME ou TWITCH_OAUTH_TOKEN não definidos — bot da Twitch desativado.");
    return;
  }

  await connect();
}

async function connect(): Promise<void> {
  if (client) {
    try { await client.disconnect(); } catch {}
    client = null;
  }

  client = new tmi.Client({
    options: { debug: false },
    identity: { username: USERNAME, password: OAUTH_TOKEN },
    channels: [CHANNEL],
  });

  client.on("connected", () => {
    console.log(`✅ [Twitch] Conectado no canal #${CHANNEL}`);
    reconnectAttempt = 0;
    reconnecting = false;
    reloadSchedule();
  });

  client.on("disconnected", (reason) => {
    console.warn(`⚠️ [Twitch] Desconectado: ${reason}`);
    clearAllIntervals();
    scheduleReconnect();
  });

  client.on("message", async (_channel, _tags, message, self) => {
    if (self) return;
    const text = message.trim();
    if (!text.startsWith("!")) return;

    const parts = text.slice(1).split(" ");
    const cmdName = parts[0].toLowerCase();

    if (cmdName === "clip") {
      await handleClipCommand();
      return;
    }

    const cmd = findCommand(cmdName);
    if (cmd) {
      try {
        await client?.say(CHANNEL, cmd.response);
      } catch (err) {
        console.error("❌ [Twitch] Erro ao responder comando:", err);
      }
    }
  });

  try {
    await client.connect();
  } catch (err) {
    console.error("❌ [Twitch] Falha ao conectar:", err);
    scheduleReconnect();
  }
}

function scheduleReconnect(): void {
  if (reconnecting) return;
  reconnecting = true;

  const delay = RECONNECT_DELAYS_MS[Math.min(reconnectAttempt, RECONNECT_DELAYS_MS.length - 1)];
  reconnectAttempt++;

  console.log(`🔄 [Twitch] Reconectando em ${delay / 1000}s... (tentativa ${reconnectAttempt})`);

  setTimeout(async () => {
    reconnecting = false;
    await connect();
  }, delay);
}

export function setLiveState(isLive: boolean): void {
  const changed = streamerIsLive !== isLive;
  streamerIsLive = isLive;

  if (!changed) return;

  if (isLive) {
    console.log("🟢 [Twitch] Streamer ao vivo — iniciando mensagens automáticas.");
    reloadSchedule();
  } else {
    console.log("⚫ [Twitch] Streamer offline — pausando mensagens automáticas.");
    clearAllIntervals();
  }
}

export function reloadSchedule(): void {
  clearAllIntervals();

  if (!client) {
    console.warn("⚠️ reloadSchedule chamado mas o bot não está conectado.");
    return;
  }

  if (!streamerIsLive) {
    console.log("ℹ️ [Twitch] Mensagens automáticas pausadas (streamer offline).");
    return;
  }

  const messages = getTwitchMessages();

  if (messages.length === 0) {
    console.log("ℹ️ [Twitch] Nenhuma mensagem automática configurada.");
    return;
  }

  for (const msg of messages) {
    const ms = msg.intervalMinutes * 60 * 1000;

    const handle = setInterval(async () => {
      try {
        await client?.say(CHANNEL, msg.message);
        console.log(`💬 [Twitch] Enviado: ${msg.message}`);
      } catch (err) {
        console.error("❌ [Twitch] Erro ao enviar mensagem:", err);
      }
    }, ms);

    intervalHandles.push(handle);
    console.log(`⏱️ [Twitch] Agendado a cada ${msg.intervalMinutes}min: "${msg.message}"`);
  }
}

async function handleClipCommand(): Promise<void> {
  const now = Date.now();
  if (now < clipCooldownUntil) {
    const secsLeft = Math.ceil((clipCooldownUntil - now) / 1000);
    try {
      await client?.say(CHANNEL, `⏳ Aguarde ${secsLeft}s para criar outro clip!`);
    } catch {}
    return;
  }

  clipCooldownUntil = now + CLIP_COOLDOWN_MS;

  try {
    const broadcasterId = await getBroadcasterId(CHANNEL);
    if (!broadcasterId) {
      await client?.say(CHANNEL, "❌ Não foi possível encontrar o canal.");
      return;
    }

    const clip = await createClip(broadcasterId);
    if (!clip) {
      await client?.say(CHANNEL, "❌ Erro ao criar o clip. Confira se a live está ativa.");
      return;
    }

    await new Promise((r) => setTimeout(r, 3_000));

    const clipUrl = `https://clips.twitch.tv/${clip.id}`;
    await client?.say(CHANNEL, `🎬 Clip criado! ${clipUrl}`);
    console.log(`✂️ [Twitch] Clip criado: ${clipUrl}`);
  } catch (err: unknown) {
    console.error("❌ [Twitch] Erro ao criar clip:", err);
    const status = (err as { response?: { status?: number } })?.response?.status;
    if (status === 401) {
      await client?.say(CHANNEL, "❌ Token sem permissão para criar clips (falta scope clips:edit).");
    } else if (status === 404) {
      await client?.say(CHANNEL, "❌ O streamer precisa estar ao vivo para criar clips.");
    } else {
      await client?.say(CHANNEL, "❌ Não foi possível criar o clip agora. Tente novamente.");
    }
  }
}

function clearAllIntervals(): void {
  for (const h of intervalHandles) clearInterval(h);
  intervalHandles = [];
}

export async function sendMessage(message: string): Promise<void> {
  if (!client) {
    console.warn("⚠️ Bot da Twitch não está conectado.");
    return;
  }
  await client.say(CHANNEL, message);
}

export function getTwitchClient(): tmi.Client | null {
  return client;
}
