import {
  SlashCommandBuilder,
  ChatInputCommandInteraction,
  PermissionFlagsBits,
  EmbedBuilder,
} from "discord.js";
import { getChatCommands, addChatCommand, removeChatCommand } from "../twitch-commands.js";

const TWITCH_PURPLE = 0x9146ff;

export const data = new SlashCommandBuilder()
  .setName("comando")
  .setDescription("Gerencia comandos de chat da Twitch (ex: !discord, !redes)")
  .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
  .addSubcommand((sub) =>
    sub
      .setName("adicionar")
      .setDescription("Adiciona ou edita um comando no chat da Twitch")
      .addStringOption((opt) =>
        opt
          .setName("nome")
          .setDescription("Nome do comando sem ! (ex: discord)")
          .setRequired(true)
      )
      .addStringOption((opt) =>
        opt
          .setName("resposta")
          .setDescription("Resposta do bot quando alguém usar o comando")
          .setRequired(true)
      )
  )
  .addSubcommand((sub) =>
    sub
      .setName("remover")
      .setDescription("Remove um comando do chat da Twitch")
      .addStringOption((opt) =>
        opt.setName("nome").setDescription("Nome do comando sem ! (ex: discord)").setRequired(true)
      )
  )
  .addSubcommand((sub) =>
    sub.setName("listar").setDescription("Lista todos os comandos de chat configurados")
  );

export async function execute(interaction: ChatInputCommandInteraction): Promise<void> {
  const sub = interaction.options.getSubcommand();

  if (sub === "adicionar") {
    const nome = interaction.options.getString("nome", true).toLowerCase().replace(/^!/, "").trim();
    const resposta = interaction.options.getString("resposta", true);

    addChatCommand(nome, resposta);

    await interaction.reply({
      embeds: [
        new EmbedBuilder()
          .setColor(TWITCH_PURPLE)
          .setTitle("✅ Comando criado!")
          .setDescription(`Quando alguém digitar **!${nome}** no chat da Twitch, o bot vai responder:\n\n> ${resposta}`)
          .setTimestamp(),
      ],
      ephemeral: true,
    });
    return;
  }

  if (sub === "remover") {
    const nome = interaction.options.getString("nome", true).toLowerCase().replace(/^!/, "").trim();
    const removed = removeChatCommand(nome);

    await interaction.reply({
      embeds: [
        new EmbedBuilder()
          .setColor(removed ? TWITCH_PURPLE : 0xff4444)
          .setTitle(removed ? "✅ Comando removido!" : "❌ Comando não encontrado")
          .setDescription(removed ? `O comando **!${nome}** foi removido.` : `Não existe nenhum comando chamado **!${nome}**.`)
          .setTimestamp(),
      ],
      ephemeral: true,
    });
    return;
  }

  if (sub === "listar") {
    const cmds = getChatCommands();

    if (cmds.length === 0) {
      await interaction.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(TWITCH_PURPLE)
            .setTitle("📋 Comandos de chat")
            .setDescription("Nenhum comando configurado ainda. Use `/comando adicionar` para criar.")
            .setTimestamp(),
        ],
        ephemeral: true,
      });
      return;
    }

    const lista = cmds.map((c) => `**!${c.name}** → ${c.response}`).join("\n");

    await interaction.reply({
      embeds: [
        new EmbedBuilder()
          .setColor(TWITCH_PURPLE)
          .setTitle(`📋 Comandos de chat (${cmds.length})`)
          .setDescription(lista)
          .setTimestamp(),
      ],
      ephemeral: true,
    });
    return;
  }
}
