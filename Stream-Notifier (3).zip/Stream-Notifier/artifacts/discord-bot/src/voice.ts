import {
  joinVoiceChannel,
  VoiceConnectionStatus,
  entersState,
  getVoiceConnection,
} from "@discordjs/voice";
import { Client, Guild, ChannelType } from "discord.js";
import { getAllConfigs } from "./config.js";

export async function joinConfiguredVoiceChannels(client: Client): Promise<void> {
  const configs = getAllConfigs();

  for (const config of configs) {
    if (!config.voiceChannelId) continue;

    const guild = await client.guilds.fetch(config.guildId).catch(() => null) as Guild | null;
    if (!guild) continue;

    const channel = await guild.channels.fetch(config.voiceChannelId).catch(() => null);
    if (!channel || channel.type !== ChannelType.GuildVoice) continue;

    const existing = getVoiceConnection(guild.id);
    if (existing) continue;

    try {
      const connection = joinVoiceChannel({
        channelId: channel.id,
        guildId: guild.id,
        adapterCreator: guild.voiceAdapterCreator,
        selfMute: true,
        selfDeaf: true,
      });

      connection.on(VoiceConnectionStatus.Ready, () => {
        console.log(`🔇 [Voz] Entrou no canal "${channel.name}" no servidor "${guild.name}" (mutado)`);
      });

      connection.on(VoiceConnectionStatus.Disconnected, async () => {
        try {
          await Promise.race([
            entersState(connection, VoiceConnectionStatus.Signalling, 5_000),
            entersState(connection, VoiceConnectionStatus.Connecting, 5_000),
          ]);
        } catch {
          console.warn(`⚠️ [Voz] Desconectado do canal "${channel.name}" — tentando reconectar...`);
          try {
            connection.destroy();
            await joinConfiguredVoiceChannels(client);
          } catch {}
        }
      });
    } catch (err) {
      console.error(`❌ [Voz] Erro ao entrar no canal "${channel.name}":`, err);
    }
  }
}

export function leaveVoiceChannel(guildId: string): void {
  const connection = getVoiceConnection(guildId);
  if (connection) {
    connection.destroy();
    console.log(`🚪 [Voz] Saiu do canal de voz no servidor ${guildId}`);
  }
}
