import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const FILE = path.join(__dirname, "..", "data", "twitch-commands.json");

export interface ChatCommand {
  name: string;
  response: string;
}

function load(): ChatCommand[] {
  try {
    if (!fs.existsSync(FILE)) return [];
    return JSON.parse(fs.readFileSync(FILE, "utf-8")) as ChatCommand[];
  } catch {
    return [];
  }
}

function save(cmds: ChatCommand[]): void {
  const dir = path.dirname(FILE);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(FILE, JSON.stringify(cmds, null, 2), "utf-8");
}

export function getChatCommands(): ChatCommand[] {
  return load();
}

export function addChatCommand(name: string, response: string): void {
  const cmds = load();
  const existing = cmds.findIndex((c) => c.name.toLowerCase() === name.toLowerCase());
  if (existing >= 0) {
    cmds[existing].response = response;
  } else {
    cmds.push({ name: name.toLowerCase(), response });
  }
  save(cmds);
}

export function removeChatCommand(name: string): boolean {
  const cmds = load();
  const idx = cmds.findIndex((c) => c.name.toLowerCase() === name.toLowerCase());
  if (idx < 0) return false;
  cmds.splice(idx, 1);
  save(cmds);
  return true;
}

export function findCommand(name: string): ChatCommand | null {
  const cmds = load();
  return cmds.find((c) => c.name.toLowerCase() === name.toLowerCase()) ?? null;
}
